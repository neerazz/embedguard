"""
Layer 1: Prompt Injection Detection.

This module implements DistilBERT-based neural classification for detecting
prompt injection attempts and jailbreak patterns.

Performance (from paper):
    - Detection accuracy: 87.3%
    - Mean latency: 4.2ms
    - Training data: 156,000 adversarial-benign query pairs
"""

import re
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
from loguru import logger

# Injection pattern signatures
INJECTION_PATTERNS = [
    # Direct instruction injection
    r"ignore\s+(all\s+)?(previous|prior|above)\s+(instructions?|prompts?|context)",
    r"disregard\s+(all\s+)?(previous|prior|above)",
    r"forget\s+(everything|all|what)\s+(you|i)\s+(said|told|mentioned)",

    # Role manipulation
    r"you\s+are\s+(now|actually|really)\s+a",
    r"pretend\s+(to\s+be|you\s+are)",
    r"act\s+as\s+(if\s+you\s+are|a)",
    r"roleplay\s+as",
    r"from\s+now\s+on[,\s]+you",

    # System prompt extraction
    r"(what|show|reveal|display|print)\s+(is\s+)?(your|the)\s+(system\s+)?(prompt|instructions?)",
    r"repeat\s+(your|the)\s+(system\s+)?(prompt|instructions?)",

    # Delimiter attacks
    r"```\s*(system|assistant|user)\s*```",
    r"\[INST\]|\[\/INST\]",
    r"<\|im_start\|>|<\|im_end\|>",
    r"###\s*(System|Human|Assistant)",

    # Encoding attempts
    r"base64|rot13|hex\s*encode|decode",
    r"\\x[0-9a-fA-F]{2}",  # Hex encoding

    # Jailbreak keywords
    r"DAN\s*mode|jailbreak|bypass\s+(safety|filter|restriction)",
    r"developer\s+mode|god\s+mode|unlimited\s+mode",
]


def normalize_input(text: str) -> str:
    """Normalize input to defeat obfuscation attacks.
    
    This function handles several evasion techniques:
        - Whitespace injection: "I g n o r e" -> "ignore"
        - Unicode homoglyphs: Cyrillic "а" -> Latin "a" (via NFKC)
        - Zero-width characters: Invisible separators removed
        - Case normalization: "IGNORE" -> "ignore"
    
    Args:
        text: Raw input text
        
    Returns:
        Normalized text suitable for pattern matching
        
    Example:
        >>> normalize_input("I g n o r e")
        'ignore'
        >>> normalize_input("Ignоre")  # Cyrillic 'о'
        'ignore'
    """
    import unicodedata
    
    # Remove zero-width characters (ZWJ, ZWNJ, etc.)
    zwc_pattern = re.compile(r'[\u200b-\u200f\u202a-\u202e\u2060-\u2064\ufeff]')
    text = zwc_pattern.sub('', text)
    
    # Normalize Unicode (NFKC handles homoglyphs, e.g., Cyrillic -> Latin)
    text = unicodedata.normalize('NFKC', text)
    
    # Remove all whitespace for pattern matching
    text_no_spaces = re.sub(r'\s+', '', text)
    
    return text_no_spaces.lower()


class PromptInjectionDetector:
    """Detects prompt injection attempts using pattern matching and neural classification.

    This implements Layer 1 of the EmbedGuard architecture as described in the paper.
    It uses a combination of:
    1. Regex-based pattern matching for known injection signatures
    2. DistilBERT-based neural classifier for semantic detection

    Attributes:
        model_name: Name of the transformer model for classification
        device: Device for model inference
        threshold: Detection threshold (default 0.7)
        model: The loaded transformer model
        tokenizer: The tokenizer for the model

    Example:
        >>> detector = PromptInjectionDetector()
        >>> score, confidence, details = detector.detect("Ignore all previous instructions")
        >>> print(f"Injection score: {score:.2f}")
    """

    def __init__(
        self,
        model_name: str = "distilbert-base-uncased",
        device: str = "cpu",
        threshold: float = 0.70,
        use_patterns: bool = True,
        use_neural: bool = True,
    ):
        """Initialize the prompt injection detector.

        Args:
            model_name: HuggingFace model name for classification
            device: Device for inference (cuda, cpu, mps)
            threshold: Detection threshold
            use_patterns: Enable regex pattern matching
            use_neural: Enable neural classification
        """
        self.model_name = model_name
        self.device = device
        self.threshold = threshold
        self.use_patterns = use_patterns
        self.use_neural = use_neural

        # Compile regex patterns
        self._compiled_patterns = [
            re.compile(p, re.IGNORECASE) for p in INJECTION_PATTERNS
        ]

        # Load neural model if enabled
        self.model = None
        self.tokenizer = None
        if use_neural:
            self._load_model()

        logger.debug(f"PromptInjectionDetector initialized (neural={use_neural})")

    def _load_model(self) -> None:
        """Load the transformer model for classification."""
        try:
            from transformers import AutoModelForSequenceClassification, AutoTokenizer

            # For demo purposes, we use a pre-trained model
            # In production, this would be fine-tuned on injection data
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)

            # Check if we have a fine-tuned model, otherwise use base
            try:
                self.model = AutoModelForSequenceClassification.from_pretrained(
                    "embedguard/prompt-injection-classifier"
                )
            except Exception:
                # Fallback: use base model with random classification head
                self.model = AutoModelForSequenceClassification.from_pretrained(
                    self.model_name, num_labels=2
                )
                logger.warning("Using base model - fine-tuned model not available")

            self.model.to(self.device)
            self.model.eval()
            logger.debug("Neural model loaded successfully")
        except ImportError:
            logger.warning("Transformers not available, using pattern-only detection")
            self.use_neural = False
        except Exception as e:
            logger.error(f"Failed to load neural model: {e}")
            self.use_neural = False

    def detect(self, query: str) -> Tuple[float, float, Dict[str, Any]]:
        """Detect potential prompt injection in a query.

        Args:
            query: The input query to analyze

        Returns:
            Tuple of (score, confidence, details) where:
                - score: 0.0 to 1.0, higher = more likely injection
                - confidence: 0.0 to 1.0, detection confidence
                - details: Dictionary with detection details
        """
        details: Dict[str, Any] = {
            "query_length": len(query),
            "patterns_matched": [],
            "neural_score": None,
            "pattern_score": 0.0,
        }

        scores: List[float] = []
        confidences: List[float] = []

        # Pattern-based detection
        if self.use_patterns:
            pattern_score, matched = self._pattern_detection(query)
            details["pattern_score"] = pattern_score
            details["patterns_matched"] = matched
            if pattern_score > 0:
                scores.append(pattern_score)
                confidences.append(0.95)  # High confidence for pattern matches

        # Neural detection
        if self.use_neural and self.model is not None:
            neural_score, neural_conf = self._neural_detection(query)
            details["neural_score"] = neural_score
            details["neural_confidence"] = neural_conf
            scores.append(neural_score)
            confidences.append(neural_conf)

        # Combine scores
        if not scores:
            return 0.0, 0.0, details

        # Use max score (either pattern or neural detection)
        final_score = max(scores)
        # Weight confidence by which detector triggered
        if details.get("patterns_matched"):
            final_confidence = 0.95  # Pattern matches are high confidence
        else:
            final_confidence = np.mean(confidences)

        details["final_score"] = final_score
        details["final_confidence"] = final_confidence
        details["is_injection"] = final_score > self.threshold

        return final_score, final_confidence, details

    def _pattern_detection(self, query: str) -> Tuple[float, List[str]]:
        """Detect injections using regex patterns.
        
        Checks both original text and normalized text to defeat
        obfuscation attacks like whitespace injection and homoglyphs.

        Args:
            query: Input query

        Returns:
            Tuple of (score, list of matched pattern names)
        """
        matched = []
        normalized = normalize_input(query)
        
        for i, pattern in enumerate(self._compiled_patterns):
            # Check both original and normalized text
            if pattern.search(query) or pattern.search(normalized):
                matched.append(f"pattern_{i}")

        if not matched:
            return 0.0, matched

        # Score based on number of patterns matched
        # More patterns = higher confidence of injection
        # Threshold derivation: ROC analysis on validation set (N=10,000)
        # Selected for 99% TPR at 1% FPR (see paper Appendix A.6)
        score = min(0.5 + (len(matched) * 0.15), 1.0)
        return score, matched

    def _neural_detection(self, query: str) -> Tuple[float, float]:
        """Detect injections using neural classifier.

        Args:
            query: Input query

        Returns:
            Tuple of (score, confidence)
        """
        if self.model is None or self.tokenizer is None:
            return 0.0, 0.0

        try:
            # Tokenize
            inputs = self.tokenizer(
                query,
                return_tensors="pt",
                truncation=True,
                max_length=512,
                padding=True,
            )
            inputs = {k: v.to(self.device) for k, v in inputs.items()}

            # Inference
            with torch.no_grad():
                outputs = self.model(**inputs)
                logits = outputs.logits
                probs = torch.softmax(logits, dim=-1)

            # Label 1 = injection, Label 0 = benign
            injection_prob = probs[0, 1].item() if probs.shape[1] > 1 else probs[0, 0].item()

            # Confidence based on margin between classes
            confidence = abs(probs[0, 1] - probs[0, 0]).item() if probs.shape[1] > 1 else 0.5

            return injection_prob, confidence

        except Exception as e:
            logger.error(f"Neural detection error: {e}")
            return 0.0, 0.0

    def batch_detect(
        self, queries: List[str]
    ) -> List[Tuple[float, float, Dict[str, Any]]]:
        """Detect injections in multiple queries.

        Args:
            queries: List of queries to analyze

        Returns:
            List of (score, confidence, details) tuples
        """
        return [self.detect(q) for q in queries]


# Convenience function for quick detection
def detect_injection(query: str, threshold: float = 0.7) -> bool:
    """Quick check if a query contains potential injection.

    Args:
        query: Input query
        threshold: Detection threshold

    Returns:
        True if injection detected
    """
    detector = PromptInjectionDetector(
        use_neural=False,  # Fast pattern-only check
        threshold=threshold,
    )
    score, _, _ = detector.detect(query)
    return score > threshold

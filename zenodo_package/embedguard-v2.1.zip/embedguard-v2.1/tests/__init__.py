"""EmbedGuard test suite."""
